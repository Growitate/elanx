import { useEffect, useState, type CSSProperties, type FormEvent, type ReactNode } from 'react'
import {
  ArrowDownRight,
  ArrowUpRight,
  AtSign,
  Check,
  ChevronDown,
  ChevronRight,
  Coffee,
  Droplets,
  Factory,
  Mail,
  Menu,
  MessageCircle,
  Phone,
  Send,
  ShieldCheck,
  Sparkles,
  Store,
  Users,
  X,
  Zap,
} from 'lucide-react'

type Page = 'home' | 'products' | 'about'
type LegalKey = 'privacy' | 'terms' | 'disclaimer'

type Flavor = {
  id: string
  name: string
  short: string
  description: string
  color: string
  accent: string
  text: string
  taste: string
  bestFor: string
  code: string
}

const flavors: Flavor[] = [
  { id: 'orange', name: 'Orange', short: 'Citrus lift', description: 'Bright citrus fizz with a sunny, juicy finish.', color: '#ff887e', accent: '#e9574d', text: '#5a281d', taste: 'Zesty · Juicy · Bright', bestFor: 'Afternoon resets', code: '01' },
  { id: 'cola', name: 'Cola', short: 'Classic depth', description: 'Rich, smooth cola with a familiar, confident finish.', color: '#6b2b20', accent: '#431812', text: '#5a281d', taste: 'Rich · Smooth · Familiar', bestFor: 'Everyday enjoyment', code: '02' },
  { id: 'lemon', name: 'Lemon', short: 'Crisp sparkle', description: 'A cool, zesty pour for a sharper kind of refreshment.', color: '#f1a82d', accent: '#d77a12', text: '#4a2015', taste: 'Crisp · Tart · Cool', bestFor: 'Hot-day refreshment', code: '03' },
  { id: 'blueberry', name: 'Blueberry', short: 'Unexpectedly lush', description: 'Deep berry notes meet playful fizz for curious sippers.', color: '#2d8eba', accent: '#126a98', text: '#5a281d', taste: 'Fruity · Lush · Playful', bestFor: 'New flavour seekers', code: '04' },
  { id: 'coffee-cola', name: 'Coffee Cola', short: 'Bold fusion', description: 'Roasted coffee warmth with classic cola refreshment.', color: '#b77851', accent: '#78442e', text: '#5a281d', taste: 'Roasted · Bold · Smooth', bestFor: 'Late-day momentum', code: '05' },
]

const pageFromPath = (): Page => {
  if (window.location.pathname.startsWith('/products')) return 'products'
  if (window.location.pathname.startsWith('/about')) return 'about'
  return 'home'
}

const legalContent: Record<LegalKey, { title: string; kicker: string; paragraphs: string[] }> = {
  privacy: { title: 'Privacy, with clarity.', kicker: 'Privacy policy', paragraphs: ['ElanX Beverages respects the information you choose to share with us. We use enquiries and contact details only to respond to your request, discuss our products, or support a potential retail or wholesale relationship.', 'We do not sell personal information. To update or remove information you have shared, email elanx.beverages@gmail.com.'] },
  terms: { title: 'Simple terms. Better business.', kicker: 'Terms of use', paragraphs: ['This website introduces ElanX Beverages, its flavour range and its business contact channels. Product availability, pricing, minimum order quantities and distribution terms may vary by location and are confirmed directly with our team.', 'By using this website, you agree to use its content for lawful purposes and not to copy, misuse or misrepresent ElanX brand materials without permission.'] },
  disclaimer: { title: 'Good taste, honest detail.', kicker: 'Disclaimer', paragraphs: ['Product descriptions are for brand and flavour communication. Packaging, availability and product specifications may change as ElanX grows its range and distribution network.', 'For current retail, wholesale and distribution information, contact elanx.beverages@gmail.com or +91 83390 94094.'] },
}

function ElanMark({ light = false }: { light?: boolean }) {
  return <span className={`elan-mark ${light ? 'elan-mark--light' : ''}`}><span className="elan-mark__symbol">E</span><span className="elan-mark__word">ELAN<span>X</span></span></span>
}

function ProductPack({ flavor, size = 'large', floating = false }: { flavor: Flavor; size?: 'large' | 'small'; floating?: boolean }) {
  const packStyle = { '--pack': flavor.color, '--pack-accent': flavor.accent, '--pack-text': flavor.text } as CSSProperties
  return <div className={`pack-wrap pack-wrap--${size} ${floating ? 'pack-wrap--floating' : ''}`} style={packStyle} aria-label={`${flavor.name} ElanX bottle illustration`}><div className="pack-shadow" /><div className="pack"><div className="pack__cap" /><div className="pack__shine" /><div className="pack__label"><span>ELAN X</span><strong>{flavor.name}</strong><small>REFRESH YOUR<br />ENERGY</small></div><div className="pack__bubble pack__bubble--one" /><div className="pack__bubble pack__bubble--two" /></div></div>
}

function PageLink({ page, current, onNavigate, children }: { page: Page; current: Page; onNavigate: (page: Page) => void; children: ReactNode }) {
  return <button className={`page-link ${current === page ? 'page-link--active' : ''}`} type="button" onClick={() => onNavigate(page)}>{children}</button>
}

function Header({ page, onNavigate }: { page: Page; onNavigate: (page: Page) => void }) {
  const [open, setOpen] = useState(false)
  const go = (next: Page) => { setOpen(false); onNavigate(next) }
  return <header className="site-header site-header--editorial"><button className="brand-link" type="button" onClick={() => go('home')} aria-label="ElanX home"><ElanMark /></button><nav className={`main-nav ${open ? 'main-nav--open' : ''}`} aria-label="Main navigation"><PageLink page="home" current={page} onNavigate={go}>Home</PageLink><PageLink page="products" current={page} onNavigate={go}>Products</PageLink><PageLink page="about" current={page} onNavigate={go}>Our story</PageLink><a className="nav-pill" href="https://wa.me/918339094094?text=Hi%20ElanX%2C%20I%27d%20like%20to%20know%20more." target="_blank" rel="noreferrer">WhatsApp <ArrowUpRight size={14} /></a></nav><button className="menu-toggle" type="button" onClick={() => setOpen((value) => !value)} aria-label={open ? 'Close menu' : 'Open menu'}>{open ? <X size={21} /> : <Menu size={21} />}</button></header>
}

function Grain() { return <div className="paper-grain" aria-hidden="true" /> }

function HomePage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  return <main className="page page-home">
    <section className="home-hero"><Grain /><div className="home-hero__shape home-hero__shape--one" /><div className="home-hero__shape home-hero__shape--two" /><div className="container home-hero__inner"><div className="hero-copy-editorial"><span className="eyebrow eyebrow--dark"><span className="eyebrow-dot" /> ELAN X / A FLAVOUR EXPERIENCE</span><h1>Your new<br /><em>favourite</em><br />refreshment.</h1><p>Five refreshing flavours for the moments that deserve a little more energy, a little more fizz, and a lot more ElanX.</p><div className="hero-actions"><button className="button button--cocoa" type="button" onClick={() => onNavigate('products')}>Meet the flavours <ArrowUpRight size={17} /></button><button className="circle-link" type="button" onClick={() => document.getElementById('home-story')?.scrollIntoView({ behavior: 'smooth' })} aria-label="Scroll to discover"><ArrowDownRight size={19} /></button></div></div><div className="hero-pack-stage"><span className="hero-note hero-note--top">BOTTLED FOR<br />GOOD MOODS</span><div className="hero-pack-orbit" /><ProductPack flavor={flavors[0]} size="large" floating /><span className="hero-note hero-note--bottom">01 / 05<br /><strong>ORANGE</strong></span><span className="spark spark--hero"><Sparkles size={17} /></span></div></div><div className="ticker ticker--coral"><span>REFRESH YOUR ENERGY</span><i>✳</i><span>TASTE THE DIFFERENCE</span><i>✳</i><span>REFRESH YOUR ENERGY</span><i>✳</i><span>TASTE THE DIFFERENCE</span></div></section>

    <section className="section-pad home-story" id="home-story"><div className="container"><div className="section-intro-row"><div><span className="eyebrow">01 / WHY ELAN X</span><h2>A little<br /><em>more alive.</em></h2></div><p>ElanX is a modern soft drink brand made for flavour-first people. Bright packaging, playful combinations and a refreshing point of view — all in one colourful range.</p></div><div className="bento-grid bento-grid--story"><article className="bento-card bento-card--brown"><span className="bento-card__label">BETTER POUR, BETTER MOOD</span><h3>Good taste<br />goes a long way.</h3><span className="bento-card__mini">A modern classic, made for the everyday.</span></article><article className="bento-card bento-card--yellow"><span className="bento-card__label">DAILY MOMENTMENT STARTS</span><h3>Bright ideas<br />begin with fizz.</h3><span className="bento-card__mini">For the desk, the drive and everything after.</span></article><article className="bento-card bento-card--blue"><div className="bento-card__art"><ProductPack flavor={flavors[3]} size="small" /></div><span className="bento-card__label">NEW MOOD</span><h3>Different<br />hits better.</h3></article><article className="bento-card bento-card--pink"><div className="bento-card__art"><ProductPack flavor={flavors[0]} size="small" /></div><span className="bento-card__label">THE SIGNATURE POUR</span><h3>Made to be<br />remembered.</h3></article><article className="bento-card bento-card--image"><div className="mini-pack-row">{flavors.slice(0, 4).map((flavor) => <ProductPack key={flavor.id} flavor={flavor} size="small" />)}</div><span className="bento-card__label">THE FULL LINEUP</span><h3>Pick your<br />kind of good.</h3></article></div></div></section>

    <section className="section-pad flavour-preview"><div className="container"><div className="section-intro-row section-intro-row--center"><div><span className="eyebrow">02 / THE FLAVOUR EDIT</span><h2>Choose your<br /><em>favourite feeling.</em></h2></div><button className="text-link" type="button" onClick={() => onNavigate('products')}>See all flavours <ArrowUpRight size={16} /></button></div><div className="preview-cards">{flavors.slice(0, 3).map((flavor) => <button className="preview-card" style={{ '--card': flavor.color, '--card-accent': flavor.accent } as CSSProperties} type="button" key={flavor.id} onClick={() => onNavigate('products')}><span className="preview-card__meta">{flavor.code} / 05</span><ProductPack flavor={flavor} size="small" /><div><h3>{flavor.name}</h3><p>{flavor.short}</p></div><span className="preview-card__arrow"><ArrowUpRight size={15} /></span></button>)}</div></div></section>

    <section className="dark-statement"><div className="container dark-statement__inner"><span className="eyebrow eyebrow--light">THE ELAN X PROMISE</span><h2>More than a drink.<br /><em>It’s a flavour experience.</em></h2><button className="button button--cream" type="button" onClick={() => onNavigate('about')}>Meet the people behind it <ArrowUpRight size={16} /></button></div></section>
  </main>
}

function ProductsPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const [selected, setSelected] = useState(flavors[0])
  return <main className="page page-products"><section className="products-hero"><Grain /><div className="container products-hero__inner"><div><span className="eyebrow eyebrow--dark"><span className="eyebrow-dot" /> 03 / THE FULL RANGE</span><h1>Meet the<br /><em>flavour</em><br />lineup.</h1><p>Five distinct pours. One unmistakable ElanX feeling. Find the can that matches your mood.</p></div><div className="products-hero__pack"><div className="hero-pack-orbit hero-pack-orbit--small" /><ProductPack flavor={selected} size="large" floating /><span className="products-hero__annotation">SELECTED / {selected.code}<br /><strong>{selected.name.toUpperCase()}</strong></span></div></div></section><section className="section-pad products-range"><div className="container"><div className="section-intro-row"><div><span className="eyebrow">04 / FIND YOUR POUR</span><h2>Pick a side<br /><em>of refreshment.</em></h2></div><p>Every ElanX flavour has its own energy. Tap a card to bring it forward.</p></div><div className="product-grid">{flavors.map((flavor) => <button key={flavor.id} className={`product-card ${selected.id === flavor.id ? 'product-card--selected' : ''}`} style={{ '--card': flavor.color, '--card-accent': flavor.accent, '--card-text': flavor.text } as CSSProperties} type="button" onClick={() => setSelected(flavor)}><div className="product-card__head"><span>{flavor.code} / ELAN X</span><ArrowUpRight size={16} /></div><div className="product-card__pack"><ProductPack flavor={flavor} size="large" /></div><div className="product-card__footer"><div><h3>{flavor.name}</h3><p>{flavor.short}</p></div><span className="product-card__swatch" /></div></button>)}</div></div></section><section className="section-pad product-detail" style={{ '--detail': selected.color, '--detail-accent': selected.accent, '--detail-text': selected.text } as CSSProperties}><div className="container product-detail__inner"><div className="product-detail__visual"><span className="eyebrow eyebrow--light">SIGNATURE POUR / {selected.code}</span><ProductPack flavor={selected} size="large" floating /></div><div className="product-detail__copy"><span className="eyebrow eyebrow--light">{selected.short}</span><h2>{selected.name}<br /><em>for the mood.</em></h2><p>{selected.description}</p><div className="product-facts"><div><span>TASTE PROFILE</span><strong>{selected.taste}</strong></div><div><span>BEST FOR</span><strong>{selected.bestFor}</strong></div></div><button className="button button--cream" type="button" onClick={() => onNavigate('about')}>Stock ElanX <ArrowUpRight size={16} /></button></div></div></section><section className="section-pad range-note"><div className="container range-note__inner"><span className="eyebrow">THE WHOLE STORY</span><h2>Five flavours.<br /><em>One good feeling.</em></h2><button className="text-link" type="button" onClick={() => onNavigate('about')}>Talk retail & wholesale <ArrowUpRight size={16} /></button></div></section></main>
}

function AboutPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const [sent, setSent] = useState(false)
  const [enquiryHref, setEnquiryHref] = useState('mailto:elanx.beverages@gmail.com')
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); const form = new FormData(event.currentTarget); const name = String(form.get('name') ?? ''); const body = `Name: ${name}\nEmail: ${form.get('email') ?? ''}\nInterest: ${form.get('interest') ?? ''}\n\n${form.get('message') ?? ''}`; setEnquiryHref(`mailto:elanx.beverages@gmail.com?subject=${encodeURIComponent(`ElanX enquiry from ${name}`)}&body=${encodeURIComponent(body)}`); setSent(true) }
  return <main className="page page-about"><section className="about-hero"><Grain /><div className="container about-hero__inner"><div><span className="eyebrow eyebrow--dark"><span className="eyebrow-dot" /> 05 / OUR STORY</span><h1>Good energy<br /><em>runs deep.</em></h1><p>Founded by Suhana Shabnam, ElanX was created to make everyday refreshment feel more distinctive, more joyful and more worth remembering.</p></div><div className="about-hero__stamp"><div className="stamp-ring"><span>ELAN X</span><strong>EX</strong><small>EST. NOW</small></div></div></div></section><section className="section-pad about-story"><div className="container about-story__grid"><div><span className="eyebrow">06 / THE BEGINNING</span><h2>A modern brand<br /><em>with a human pulse.</em></h2></div><div><p className="lead-copy">We believe a soft drink can do more than refresh. It can change the tempo of a day, bring people to the same table and make a familiar moment feel new.</p><p>That is why ElanX brings classic favourites and unexpected combinations together in a range that looks as good on the shelf as it tastes in the hand.</p></div></div><div className="container values-grid"><article className="value-card value-card--pink"><Sparkles size={21} /><span>01</span><h3>Flavour<br />first.</h3><p>We start with the sip and build the story around it.</p></article><article className="value-card value-card--yellow"><Zap size={21} /><span>02</span><h3>Energy<br />with intent.</h3><p>Bright, bold and made to move the room.</p></article><article className="value-card value-card--blue"><ShieldCheck size={21} /><span>03</span><h3>Built for<br />partnership.</h3><p>Retail, wholesale and distribution with a clear point of view.</p></article></div></section><section className="section-pad contact-section-editorial" id="contact"><div className="container contact-editorial-grid"><div><span className="eyebrow">07 / LET’S TALK</span><h2>Bring some<br /><em>good energy.</em></h2><p>For retail, wholesale, distribution or simply a question about the range, our team would love to hear from you.</p><div className="contact-details-editorial"><a href="mailto:elanx.beverages@gmail.com"><Mail size={17} /> elanx.beverages@gmail.com</a><a href="tel:+918339094094"><Phone size={17} /> +91 83390 94094</a><a href="https://instagram.com/elanxbeverages" target="_blank" rel="noreferrer"><AtSign size={17} /> @ElanX Beverages</a></div></div><div className="enquiry-card">{sent ? <div className="form-success"><span className="form-success__icon"><Check size={22} /></span><span className="eyebrow">YOUR DRAFT IS READY</span><h3>Let’s keep it moving.</h3><p>Your enquiry is ready as an email draft. Open it to send your details to the ElanX team.</p><a className="button button--cocoa" href={enquiryHref}>Open email draft <Mail size={17} /></a></div> : <form onSubmit={handleSubmit}><span className="eyebrow">SEND A NOTE</span><h3>Let’s talk flavour.</h3><label>Your name<input required name="name" placeholder="Your name" /></label><label>Your email<input required name="email" type="email" placeholder="you@company.com" /></label><label>I’m interested in<select name="interest" defaultValue="retail"><option value="retail">Retail partnership</option><option value="wholesale">Wholesale & distribution</option><option value="flavours">Finding my flavour</option></select><ChevronDown size={16} /></label><label>Your message<textarea required name="message" rows={3} placeholder="Tell us what you have in mind..." /></label><button className="button button--cocoa button--full" type="submit">Prepare enquiry <Send size={16} /></button></form>}</div></div></section><section className="about-cta"><div className="container about-cta__inner"><div><span className="eyebrow eyebrow--light">READY WHEN YOU ARE</span><h2>Find your<br /><em>flavour.</em></h2></div><button className="button button--cream" type="button" onClick={() => onNavigate('products')}>Explore products <ArrowUpRight size={16} /></button></div></section></main>
}

function Footer({ onNavigate, onLegal }: { onNavigate: (page: Page) => void; onLegal: (key: LegalKey) => void }) {
  return <footer className="site-footer site-footer--editorial"><div className="container footer-editorial-top"><div><ElanMark light /><p>More than a drink.<br />It’s a flavour experience.</p></div><div className="footer-editorial-links"><div><span>Explore</span><button type="button" onClick={() => onNavigate('home')}>Home</button><button type="button" onClick={() => onNavigate('products')}>Products</button><button type="button" onClick={() => onNavigate('about')}>Our story</button></div><div><span>Connect</span><a href="mailto:elanx.beverages@gmail.com">Email us</a><a href="https://wa.me/918339094094" target="_blank" rel="noreferrer">WhatsApp</a><a href="https://instagram.com/elanxbeverages" target="_blank" rel="noreferrer">Instagram</a></div></div><div className="footer-editorial-cta"><span>Good things<br />are better shared.</span><button className="button button--cream" type="button" onClick={() => onNavigate('about')}>Make an enquiry <ArrowUpRight size={16} /></button></div></div><div className="container footer-editorial-bottom"><span>© 2025 ElanX Beverages</span><div><button type="button" onClick={() => onLegal('privacy')}>Privacy</button><button type="button" onClick={() => onLegal('terms')}>Terms</button><button type="button" onClick={() => onLegal('disclaimer')}>Disclaimer</button></div><span>Made for memorable moments.</span></div></footer>
}

function LegalModal({ legalKey, onClose }: { legalKey: LegalKey; onClose: () => void }) {
  const content = legalContent[legalKey]
  useEffect(() => { const close = (event: KeyboardEvent) => event.key === 'Escape' && onClose(); window.addEventListener('keydown', close); return () => window.removeEventListener('keydown', close) }, [onClose])
  return <div className="modal-backdrop" onClick={onClose}><div className="legal-modal legal-modal--editorial" role="dialog" aria-modal="true" onClick={(event) => event.stopPropagation()}><button className="icon-button" type="button" onClick={onClose} aria-label="Close legal content" autoFocus><X size={18} /></button><span className="eyebrow">{content.kicker}</span><h2>{content.title}</h2>{content.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}<button className="button button--cocoa" type="button" onClick={onClose}>Back to ElanX <ArrowUpRight size={16} /></button></div></div>
}

function App() {
  const [page, setPage] = useState<Page>(pageFromPath)
  const [legalKey, setLegalKey] = useState<LegalKey | null>(null)
  useEffect(() => { const handlePop = () => setPage(pageFromPath()); window.addEventListener('popstate', handlePop); document.body.style.overflow = legalKey ? 'hidden' : ''; return () => { window.removeEventListener('popstate', handlePop); document.body.style.overflow = '' } }, [legalKey])
  const navigate = (next: Page) => { const path = next === 'home' ? '/' : `/${next}`; window.history.pushState({}, '', path); setPage(next); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  return <div className="site-shell site-shell--editorial"><Header page={page} onNavigate={navigate} />{page === 'home' && <HomePage onNavigate={navigate} />}{page === 'products' && <ProductsPage onNavigate={navigate} />}{page === 'about' && <AboutPage onNavigate={navigate} />}<Footer onNavigate={navigate} onLegal={setLegalKey} />{legalKey && <LegalModal legalKey={legalKey} onClose={() => setLegalKey(null)} />}</div>
}

export default App
